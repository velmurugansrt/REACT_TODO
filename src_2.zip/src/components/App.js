import React, { Component } from 'react';
// import logo from '../assets/images/logo.svg';
import Login from './login';
import Singup from './singup';
import Home from './home';
import '../assets/css/App.css';
import { BrowserRouter as Router, Route } from "react-router-dom";

class App extends Component {
  render() {
    return (
      <Router>
        <div>
          <Route exact path="/login" component={Login} />
          <Route exact path="/signup" component={Singup} />
          <Route exact path="/" component={Home} />
        </div>
      </Router>
    );
  }
}

export default App;
