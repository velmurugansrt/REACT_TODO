import React, { Component } from 'react';
import '../assets/css/App.css';
import { Link } from "react-router-dom";

class App extends Component {

  state = {
    mail: '',
    password: '',
  }

  componentWillMount() {
    if(localStorage.getItem("logged")!=null){
      this.props.history.push("/");
    }
  }
  login(e) {
    e.preventDefault();
    const reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if ((!this.state.mail.match(reg)) || this.state.mail == "") {
      alert("Please enter correct email");
    } else if (this.state.password == "") {
      alert("Please enter password");
    } else {
      var users = localStorage.getItem('users');
      var user_data = { email: this.state.mail, password: this.state.password };
      if (users != null) {
        var old_users = JSON.parse(users);
        var mail = this.state.mail;
        var user_value = old_users.find(function (obj) { return obj.email === mail; });
        if (user_value != undefined) {
          old_users.push(user_data);
          if (user_value.password == this.state.password) {
            var users = localStorage.setItem('logged',JSON.stringify(user_value));
            this.props.history.push("/");
          } else {
            alert("Password incorrect");
          }
        } else {
          alert("User not found!");
        }
      } else {
        alert("User not found!");
      }
    }
  }
  render() {
    return (
      <div className="limiter">
        <div className="container-login100">
          <div className="wrap-login100">
            <form className="login100-form validate-form" method="POST">
              <span className="login100-form-title p-b-26">
                Login
              </span>
              <span className="login100-form-title p-b-48">
                <i className="zmdi zmdi-font"></i>
              </span>


              <div className="wrap-input100 validate-input" data-validate="Valid email is: a@b.c">
                <input className="input100" type="text" name="email" placeholder="Email" value={this.state.mail}  onChange={(mail) => this.setState({ mail: mail.target.value })} />
                <span className="focus-input100" placeholder="Email"></span>
              </div>

              <div className="wrap-input100 validate-input" data-validate="Enter password">
                <span className="btn-show-pass">
                  <i className="zmdi zmdi-eye"></i>
                </span>
                <input className="input100" type="password" placeholder="Password" name="pass" value={this.state.password} onChange={(password) => this.setState({ password: password.target.value })} />
                <span className="focus-input100"></span>
              </div>

              <div className="container-login100-form-btn">
                <div className="wrap-login100-form-btn">
                  <div className="login100-form-bgbtn"></div>
                  <button className="login100-form-btn" onClick={(e) => this.login(e)}>
                    Login
                    </button>
                </div>
              </div>

              <div className="text-center p-t-115">
                <span className="txt1">
                  Don’t have an account?
              </span>
                <Link to="/signup">
                  <a className="txt2" href="#">
                    Sign Up
                   </a>
                </Link>
              </div>
            </form>
          </div>
        </div>
      </div>
    );
  }
}

export default App;
