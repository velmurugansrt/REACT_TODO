import React, { Component } from 'react';
import '../assets/css/App.css';
import { Link } from "react-router-dom";

class App extends Component {

  state = {
    mail: '',
    password: '',
    name: '',
    title: '',
    date: new Date(),
    description: '',
    todo_list: []
  }
  componentWillMount() {

    if (new_user_todo != null) {
      var user_value = new_user_todo.filter(function (obj) { return obj.user_id === user_id; });
      this.setState({ todo_list: user_value });
    }
    if (localStorage.getItem("logged") == null) {
      this.props.history.push("/login");
    } else {
      var user_id = JSON.parse(localStorage.getItem("logged")).user_id;
      var new_user_todo = JSON.parse(localStorage.getItem('todo_list'));
      this.setState({ name: JSON.parse(localStorage.getItem("logged")).email });
    }
  }
  login(e) {
    e.preventDefault();
    const reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if ((!this.state.mail.match(reg)) || this.state.mail == "") {
      alert("Please enter correct email");
    } else if (this.state.password == "") {
      alert("Please enter password");
    } else {
      var users = localStorage.getItem('users');
      var user_data = { email: this.state.mail, password: this.state.password };
      if (users != null) {
        var old_users = JSON.parse(users);
        var mail = this.state.mail;
        var user_value = old_users.find(function (obj) { return obj.email === mail; });
        if (user_value != undefined) {
          old_users.push(user_data);
          if (user_value.password == this.state.password) {

          } else {
            alert("Password incorrect");
          }
        } else {
          alert("User not found!");
        }
      } else {
        alert("User not found!");
      }
    }
  }
  logout(e) {
    e.preventDefault();
    localStorage.removeItem("logged")
    this.props.history.push("/login");
  }
  addtodo(e) {
    e.preventDefault();

    var user_id = JSON.parse(localStorage.getItem("logged")).user_id;
    var todo_data = { todo_id: 'todo_' + Math.floor(100000 + Math.random() * 900000), user_id: user_id, title: this.state.title, date: this.state.date.split('-')[2] + '-' + this.state.date.split('-')[1] + '-' + this.state.date.split('-')[0], description: this.state.description }
    var local_data = localStorage.getItem('todo_list');
    if (local_data == null) {
      localStorage.setItem('todo_list', JSON.stringify([todo_data]));
      var new_user_todo = JSON.parse(localStorage.getItem('todo_list'));
      var user_value = new_user_todo.filter(function (obj) { return obj.user_id === user_id; });
      this.setState({ todo_list: user_value });
      this.setState({ title: '', date: new Date(), description: '' })
    } else {
      var new_local_data = JSON.parse(local_data);
      new_local_data.push(todo_data)
      localStorage.setItem('todo_list', JSON.stringify(new_local_data))
      var new_user_todo = JSON.parse(localStorage.getItem('todo_list'));
      var user_value = new_user_todo.filter(function (obj) { return obj.user_id === user_id; });
      this.setState({ todo_list: user_value });
      this.setState({ title: '', date: new Date(), description: '' })

    }
  }
  check(id, index) {
    if (id == 1) {
      var list = this.state.todo_list;
      list[index].check = true;
      this.setState({ todo_list: list });
    } else {
      var list = this.state.todo_list;
      list[index].check = false;
      this.setState({ todo_list: list });
    }

  }
  delete() {
    var list = this.state.todo_list;
    var delete_value = list.filter(function (obj) { return obj.check; });
    if (delete_value.length > 0) {
      var old_data = JSON.parse(localStorage.getItem('todo_list'));
      for (var i in delete_value) {
        var user_value = old_data.findIndex(function (obj) { return obj.todo_id === delete_value[i].todo_id; });
        old_data.splice(user_value, 1);
      }
      var user_id = JSON.parse(localStorage.getItem("logged")).user_id;
      localStorage.setItem('todo_list', JSON.stringify(old_data));
      var user_value = old_data.filter(function (obj) { return obj.user_id === user_id; });
      this.setState({ todo_list: user_value });

    } else {
      alert("Plaese select atleast one");
    }

  }
  render() {

    return (
      <div className="col-lg-12 todo-container">
        <div className="row">
          <nav className="navbar navbar-default navigation-clean-button nopadding">
            <div className="container">
              <div className="navbar-header"><a className="navbar-brand" href="#">Welcome <span className="brand-color">Todo</span></a>
                <button className="navbar-toggle collapsed" data-toggle="collapse" data-target="#navcol-1"><span className="sr-only">Toggle navigation</span><span className="icon-bar"></span><span className="icon-bar"></span><span className="icon-bar"></span></button>
              </div>
              <div className="collapse navbar-collapse" id="navcol-1">
                <p className="navbar-text navbar-right actions"><a className="navbar-link login">{this.state.name}</a> <a className="btn btn-default action-button" role="button" onClick={(e) => this.logout(e)}>Signout</a></p>
              </div>
            </div>
          </nav>
        </div>
        <div className="row">
          <div className="col-lg-3 add-todo-wrap" >
            <div className="col-lg-12  add-todo">
              <div className="row padding">
                <h4 className="text-center heading">Add Todo</h4>
                <div class="form-group">
                  <label for="usr">Title:</label>
                  <input type="text" class="form-control" id="usr" value={this.state.title} onChange={(title) => this.setState({ title: title.target.value })} />
                </div>
                <div class="form-group">
                  <label for="usr">Date:</label>
                  <input type="date" class="form-control" id="start" name="trip"
                    value={this.state.date} onChange={(date) => this.setState({ date: date.target.value })} />
                </div>
                <div class="form-group">
                  <label for="usr">Description:</label>
                  <textarea type="text" class="form-control" id="usr" value={this.state.description} onChange={(description) => this.setState({ description: description.target.value })} />
                </div>

                <a className="btn btn-default action-button" role="button" onClick={(e) => this.addtodo(e)}>Add</a>

              </div>
            </div>
          </div>
          <div className="col-lg-9 todo-list-wrap">
            <div className="col-lg-12 todo-list">
              <div className="row padding">
                <h3 className="text-center heading">Tasks</h3>
              </div>
              <div className="row padding">
                {this.state.todo_list.map((list, index) =>
                  <div className="col-lg-4" key={list.todo_id} >
                    <div className="card">
                      <h4 className="card-title">{list.title}</h4>
                      <h5 className="card-title"><i>{list.date}</i></h5>
                      <p className="card-title">{list.description}</p>
                      {list.check ?
                        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/d/dd/Pink_checkbox-checked.svg/2000px-Pink_checkbox-checked.svg.png" alt="Italian Trulli" className="uncheck" onClick={() => this.check(0, index)} />
                        :
                        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e9/Pink_checkbox-unchecked.svg/2000px-Pink_checkbox-unchecked.svg.png" alt="Italian Trulli" className="uncheck" onClick={() => this.check(1, index)} />
                      }
                    </div>
                  </div>
                )}
                
                {this.state.todo_list.length>0?null
                :
                <h4 className="card-title text-center">No task available</h4>                
                }
                {this.state.todo_list.length>0?
                <img src="https://antirevokedownload.org/wp-content/uploads/2018/04/Delete-Anti-Revoke.png" alt="Italian Trulli" className="delete" onClick={() => this.delete()} />
                :null}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default App;
