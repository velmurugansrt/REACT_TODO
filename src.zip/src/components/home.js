import React, { Component } from 'react';
import '../assets/css/App.css';
import { Link } from "react-router-dom";

class App extends Component {

  state = {
    mail: '',
    password: '',
    name:''
  }
  componentWillMount() {
    if(localStorage.getItem("logged")==null){
      this.props.history.push("/login");
    }else{
      this.setState({name:JSON.parse(localStorage.getItem("logged")).email});
    }
  }
  login(e) {
    e.preventDefault();
    const reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if ((!this.state.mail.match(reg)) || this.state.mail == "") {
      alert("Please enter correct email");
    } else if (this.state.password == "") {
      alert("Please enter password");
    } else {
      var users = localStorage.getItem('users');
      var user_data = { email: this.state.mail, password: this.state.password };
      if (users != null) {
        var old_users = JSON.parse(users);
        var mail = this.state.mail;
        var user_value = old_users.find(function (obj) { return obj.email === mail; });
        console.log(user_value);
        if (user_value != undefined) {
          old_users.push(user_data);
          if (user_value.password == this.state.password) {

          } else {
            alert("Password incorrect");
          }
        } else {
          alert("User not found!");
        }
      } else {
        alert("User not found!");
      }
    }
  }
  logout(e){
    e.preventDefault();
    localStorage.removeItem("logged")
    this.props.history.push("/login");
  }
  render() {

    return (
      <div className="col-lg-12 todo-container">
        <div className="row">
          <nav className="navbar navbar-default navigation-clean-button nopadding">
            <div className="container">
              <div className="navbar-header"><a className="navbar-brand" href="#">Welcome <span className="brand-color">Todo</span></a>
                <button className="navbar-toggle collapsed" data-toggle="collapse" data-target="#navcol-1"><span className="sr-only">Toggle navigation</span><span className="icon-bar"></span><span className="icon-bar"></span><span className="icon-bar"></span></button>
              </div>
              <div className="collapse navbar-collapse" id="navcol-1">
                <p className="navbar-text navbar-right actions"><a className="navbar-link login">{this.state.name}</a> <a className="btn btn-default action-button" role="button" onClick={(e) => this.logout(e)}>Signout</a></p>
              </div>
            </div>
          </nav>
        </div>
        <div className="row">
          <div className="col-lg-3 add-todo-wrap" >
            <div className="col-lg-12  add-todo text-center">
                <div className="row">
                  <h3 className="text-center heading">Add Todo</h3>
                </div>
            </div>
          </div>
          <div className="col-lg-9 todo-list-wrap">
            <div className="col-lg-12 todo-list">
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default App;
